/* Copyright (C) 2006 Peter Selinger. This file is distributed under
   the terms of the GNU General Public License. See the file COPYING
   for details. */

#include <stdio.h>
#include <unistd.h>

/* do something innocent */
int main_good(int ac, char *av[]) {
  printf("My name is Tina Ge and my netID is tg2213.\n");
  printf("This is a GOOD program.\n");
  return 0;
}

/* do something evil */
int main_evil(int ac, char *av[]) {
  printf("My name is Tina Ge and my netID is tg2213.\n");
  printf("This is an EVIL program.\n");
  return 0;
}
