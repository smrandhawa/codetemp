#include <stdio.h>

int main_good(void) {
    printf("My name is Corban and my netid is cbv8942\nThis is a GOOD program!\n\n");
    return 0;
}

int main_evil(void) {
    printf("My name is Corban and my netid is cbv8942\nThis is an EVIL program (rawr)!\n\n");
    return 0;
}
