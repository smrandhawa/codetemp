#include <string.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
    bad_func(argv[1]);
    return 0;
}
void bad_func(char *str)
{
    char buffer[100];
    strcpy(buffer, str);
}