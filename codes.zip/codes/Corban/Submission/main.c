// std includes for io
#include <stdio.h>
#include <stdlib.h>

void uncalled() {
    puts("The uncalled function was called!");
}

void echo() {
    char buf[4];
    gets(buf);
    printf(buf);
    printf("\n");
}

int main() {
    echo();

    return 0;
}
