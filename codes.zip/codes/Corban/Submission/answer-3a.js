var allCookies = document.cookie;
console.log(allCookies);