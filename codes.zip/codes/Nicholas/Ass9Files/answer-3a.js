alert(document.cookie);
