#include <string.h>
#include <stdio.h>

void bad() {
	printf("%s\n", "AHAHHAHAHA");
}

void function(char *str){
	char buffer[5];
	strcpy(buffer, str); 
} 

void main(int argc, char *argv[]) {
	function(argv[1]);
}