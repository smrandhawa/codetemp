#include <stdio.h>
#include <string.h>

void overflow(char *inp){
    char buf[100];
    printf("%p\n",&buf[0]); // printing address of the first buffer element
    strcpy(buf, inp);
    printf("Hello %s\n", buf);
}

int main(int argc, char *argv[]){
   overflow(argv[1]);
   return 0;
}
