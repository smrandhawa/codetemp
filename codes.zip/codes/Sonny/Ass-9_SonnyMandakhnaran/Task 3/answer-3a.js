alert(document.cookie);
